# Bitget AI Trading Command Center

A self-hosted Bitget **spot** trading research and execution starter project. It includes paper trading, an explicitly gated live-trading path, a six-agent pipeline, a dashboard, source diagnostics, and SQLite audit logs.

> **Important:** This is a working starter implementation, not a proven profitable strategy or a financial adviser. It does not guarantee profits. The included strategy is a conservative technical-momentum example, not a claim to reproduce a profitable “50-year veteran” system. Live execution can lose money. Keep live trading disabled until you have tested the software and reviewed every risk rule.

## What is included

- SCOUT: Bitget spot USDT watchlist data and 1-minute candles.
- FILTER: deterministic data, spread and liquidity checks. Missing data is rejected.
- ANALYST: EMA(9/21), RSI(14), 5m/20m momentum, volume expansion and 24h quote-volume score. Optional Grok score overlay (20% max weight), Fear & Greed and CryptoPanic headlines.
- EXECUTOR: paper ledger by default; optional Bitget Classic Spot market orders.
- RISK: risk manager runs before every scan, -6% hard stop, +12% trailing activation, 6% below peak trailing stop.
- LOGGER: SQLite scans, trades, decisions and agent events.
- Admin dashboard with password change, connection tests, mode controls, emergency kill switch, positions and trade history.

The original PDF described a Solana token-discovery system. This project adapts the six-agent separation to Bitget **spot pairs**. Solana-specific mint-authority, LP-lock, holder-cluster and RugCheck rules do not apply to ordinary Bitget spot listings, so they are not falsely represented as implemented. Instead, the FILTER checks the available Bitget market data (spread, liquidity and data integrity). This version does not yet do full on-chain wallet-cluster analysis.

## Requirements

- Python 3.10+
- A computer or VPS that can stay online for the risk monitor
- Bitget account for market data; API credentials only for private account checks and live execution
- Optional xAI API key for Grok
- Optional CryptoPanic API key for news

## Quick start (Windows / macOS / Linux)

1. Extract the ZIP.
2. Open a terminal in the project folder.
3. Create a virtual environment:

   ```bash
   python -m venv .venv
   ```

4. Activate it:

   Windows:
   ```powershell
   .venv\Scripts\activate
   ```

   macOS/Linux:
   ```bash
   source .venv/bin/activate
   ```

5. Install packages:

   ```bash
   pip install -r requirements.txt
   ```

6. Copy `.env.example` to `.env`.
7. Set `APP_SECRET_KEY` to a long random value. Set `BOOTSTRAP_ADMIN_PASSWORD=Zee@123` for the first launch if you want the requested initial password. The app hashes it at first startup and forces a change on first login. After first login, change it to a unique password of at least 12 characters.
8. Start the server:

   ```bash
   python app.py
   ```

9. Open `http://127.0.0.1:8000` and sign in:
   - Username: `admin`
   - Initial password: `Zee@123` (only if you set it in `.env` before first startup)

The initial password is not hardcoded in the browser. The server stores only an Argon2 password hash. If the database already exists, changing `BOOTSTRAP_ADMIN_PASSWORD` will not reset the existing password.

## API setup

### Bitget
Create a dedicated API key in Bitget. Enable **read** and **spot trade** only if needed. Disable withdrawal permissions. Bind the key to a fixed server IP if possible. Store key, secret and passphrase only in `.env`; never paste them into the dashboard or source code.

This implementation uses Bitget Classic Spot v2 endpoints:
- Public ticker: `/api/v2/spot/market/tickers`
- Public candles: `/api/v2/spot/market/candles`
- Private spot assets: `/api/v2/spot/account/assets`
- Spot market order: `/api/v2/spot/trade/place-order`
- Order confirmation: `/api/v2/spot/trade/orderInfo`

Bitget now recommends Unified Trading Account for new API development and maintains separate Classic/UTA API documentation. This starter currently targets Classic Spot v2 endpoints; verify your account type and current Bitget documentation before use. If your account is UTA-only, adapt to the UTA v3 endpoints before enabling live orders.

### xAI / Grok (optional)
Set `XAI_API_KEY`. The current implementation calls the OpenAI-compatible xAI chat-completions endpoint and uses `XAI_MODEL` from `.env`. The default model is `grok-4.7`; change it to a model available to your xAI API key. If Grok is unavailable, deterministic scoring still works.

### CryptoPanic (optional)
Set `CRYPTOPANIC_API_KEY` to enable headlines. If not configured, news is skipped and the dashboard source test reports that it is optional.

Fear & Greed is read from Alternative.me. It is context only and is not currently part of the entry score.

## Paper mode

Paper mode is the default. It starts with $1,000 simulated USDT. The simulator estimates 0.1% fees on each side and does not reproduce actual order-book depth, exchange queue position, partial fills, funding, or real slippage. It is not a substitute for exchange demo trading.

Run paper mode for at least several weeks and compare decisions with actual market conditions. Review logs and source tests. Do not infer profitability from a few winning trades.

## Live mode — deliberately locked

Live trading is OFF by default. The live execution path requires all of the following:

1. A dedicated Bitget API key with read + spot trade permissions and withdrawals disabled.
2. `.env`: `LIVE_TRADING_ENABLED=true`.
3. `.env`: `LIVE_CONFIRM_PHRASE` set to a long unique phrase.
4. Valid Bitget API key, secret and passphrase in `.env`.
5. Successful private account test in **Source Tests**.
6. Manual **Arm live trading** action in the dashboard.
7. Explicit mode switch to live, entering the exact confirmation phrase.
8. Release the kill switch and explicitly enable automation.

Arming live does not enable automation. The kill switch stops new entries and manual approvals; it does not close existing positions. With automation OFF, you can manually approve a recent PASS candidate (semi-auto mode). With automation ON, the bot can enter approved candidates by itself (full-auto mode). Risk monitoring continues while the app process is running.

**Operational limitation:** This starter's stop and trailing logic is monitored by this app. If the app, VPS, network, or API is down, the local risk manager cannot act. Although the buy request includes Bitget's preset stop-loss fields, verify that the exchange accepted and activated those fields for your account and order type. Do not rely on a local stop as guaranteed protection. Before live deployment, implement and test exchange-native protective orders, startup position reconciliation, partial-fill handling, and independent alerting.

## Strategy and risk defaults

- Watchlist: BTC, ETH, SOL, BNB, XRP, DOGE and LINK USDT spot pairs.
- Score threshold: 0.60.
- Allocation: max 8% of estimated equity per position.
- Max open positions: 3.
- Hard stop: -6% from entry.
- Trailing activation: +12% unrealized PnL.
- Trailing distance: 6% below peak after activation.
- Risk monitor runs before new scan entries.
- The score uses EMA alignment, RSI range, 5m/20m momentum, volume expansion, spread and 24h quote liquidity.
- Grok can contribute up to 20% of the score; it cannot override filters or risk rules.

The PDF's Solana-specific thresholds (e.g. $50k 1-hour pool volume, top-10 holders, LP lock and mint/freeze authorities) are not directly transferable to Bitget spot assets. The PDF also warns that tight stops can whipsaw and that a process must reject unverifiable conditions. This app follows fail-closed behavior for missing market data, but its current stop monitor uses each scan's latest ticker rather than a fully exchange-native 1-minute close/TWAP engine.

## Source Tests tab

Tests:
- Bitget public ticker endpoint
- Bitget private account endpoint (requires API credentials)
- Alternative.me Fear & Greed
- CryptoPanic (optional)
- xAI model endpoint (optional)

A successful connection test confirms reachability/authentication only. It does not prove data quality, strategy profitability, or safe order execution.

## Security and deployment

- Keep `.env` private; it is excluded by `.gitignore`.
- Use HTTPS and set `COOKIE_SECURE=true` behind a correctly configured reverse proxy.
- Do not expose the app directly to the public internet without TLS, firewalling, rate limiting, CSRF protection, and hardened session management.
- Use a unique admin password after first login.
- Back up the SQLite database securely.
- Use a dedicated exchange sub-account/API key and withdrawal-disabled permissions.
- For a VPS, configure process supervision (systemd/Docker restart policy) and monitoring.
- This prototype has no multi-user roles, 2FA, exchange-native OCO reconciliation, or production-grade secret vault.

## Run with Docker

```bash
cp .env.example .env
# Edit .env, then:
docker build -t bitget-ai-bot .
docker run --env-file .env -p 8000:8000 -v "$PWD/data:/app/data" bitget-ai-bot
```

For persistent DB location, set `DB_PATH=/app/data/trading_bot.db` in `.env`.

## Troubleshooting

- **Admin password not accepted:** ensure `.env` existed before the first run and the database was created. Delete `trading_bot.db` only if you intentionally want to reset the local app and all its logs.
- **Private Bitget test fails:** verify API key, secret, passphrase, account type, permissions, IP whitelist and Bitget API availability.
- **No scans:** check Bitget public source status and application logs.
- **Grok unavailable:** check key, quota, and configured model name; deterministic scoring continues.
- **No news:** CryptoPanic key is optional.
- **Live mode blocked:** verify `LIVE_TRADING_ENABLED=true`, credentials, confirmation phrase, successful private test and live arming.

## Current limitations / next engineering gates

Before calling this production-ready, add:
- UTA v3 support if required by the account.
- Startup reconciliation of balances, open orders and exchange holdings.
- Exchange-native stop/TP order verification and trailing-stop amendment.
- Partial-fill and rejected-order recovery.
- Tick/lot/min-notional precision from Bitget symbol metadata.
- Backtesting with out-of-sample periods, fees and slippage.
- Strategy performance analytics (drawdown, Sharpe, win rate, expectancy).
- News relevance and source reliability scoring.
- Rate limiting, 2FA, CSRF protection and hardened deployment.
- Automated test coverage against Bitget demo environment.

## References

- Bitget official API overview: https://www.bitget.com/docs/uta/Introduction
- Bitget Classic Spot trade API: https://www.bitget.com/docs/catalog/classic-spot-trade/classic-spot-trade
- Bitget Classic Spot account assets: https://www.bitget.com/legacy-docs/classic/spot/account/Get-Account-Assets
- Bitget demo trading guide: https://www.bitget.com/docs/classic/demo-trading/rest-api
- xAI API documentation: https://api.x.ai/docs/
- Uploaded source: `GrokAITradingBotSetupGuide.pdf` (six-agent blueprint and operational caveats)

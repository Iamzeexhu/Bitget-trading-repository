import importlib.util

def test_source_contains_risk_rules():
    source = open("app.py", encoding="utf-8").read()
    assert "HARD_STOP = 0.06" in source
    assert "TRAIL_ACTIVATE = 0.12" in source
    assert "TRAIL_GAP = 0.06" in source
    assert "POSITION_FRACTION = 0.08" in source

def test_password_is_not_frontend_hardcoded():
    html = open("static/index.html", encoding="utf-8").read()
    assert "Zee@123" not in html
